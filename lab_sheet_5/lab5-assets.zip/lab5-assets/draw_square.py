
size = int(input("Size of the square: "))

line = ""

for i in range(size):
  line += "o";

for i in range(size):
  print(line);
